package com.vaistra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VaistaApplicationTests {

	@Test
	void contextLoads() {
	}

}
