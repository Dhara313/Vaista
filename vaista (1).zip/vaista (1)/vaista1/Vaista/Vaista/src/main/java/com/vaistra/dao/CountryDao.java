package com.vaistra.dao;

import com.vaistra.entity.country;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


import java.util.List;
import java.util.Optional;

public interface CountryDao extends JpaRepository<country,Integer> {

   Page<country>findAll(Pageable pageable);
    void deleteById(Integer NO);

    Object findByNO(Integer no);

    @Query("SELECT c FROM country c")
    List<country> findBySort(Sort sort);


}



