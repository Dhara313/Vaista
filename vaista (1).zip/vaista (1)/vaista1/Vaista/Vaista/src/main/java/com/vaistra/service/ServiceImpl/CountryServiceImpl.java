package com.vaistra.service.ServiceImpl;

import com.vaistra.dao.CountryDao;
import com.vaistra.dto.CountryDto;
import com.vaistra.entity.country;
import com.vaistra.service.CountryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class CountryServiceImpl implements CountryService {


    private final CountryDao countryDao;

    @Autowired
    public CountryServiceImpl( CountryDao countryDao) {
        this.countryDao = countryDao;
    }




    public static CountryDto countryToDto( country country) {

        return new CountryDto(country.getNO(), country.getCOUNTRY(), country.isSTATUS(), country.isDELETED());

    }
    public static country dtoToCountry(CountryDto dto) {
        return new country(dto.getNO(), dto.getCOUNTRY(), dto.isSTATUS(), dto.isDELETED());
    }

    public static List<CountryDto> countriesToDtos(List<country> countries) {
        List<CountryDto> dtos = new ArrayList<>();
        for (country c : countries) {
            dtos.add(new CountryDto(c.getNO(), c.getCOUNTRY(), c.isSTATUS(), c.isDELETED()));
        }
        return dtos;
    }

    public static List<country> dtosToCountries(List<CountryDto> dtos) {
        List<country> countries = new ArrayList<>();
        for (CountryDto dto : dtos) {
            countries.add(new country(dto.getNO(), dto.getCOUNTRY(), dto.isSTATUS(), dto.isDELETED()));

        }
        return countries;
    }










    @Override
    public CountryDto addCountry(CountryDto c) {

        // HANDLE DUPLICATE NAME ENTRY EXCEPTION
        country country = countryDao.findByCountryName(c.getCOUNTRY());
        if(country != null)
            throw new DuplicateEntryException("Country with name '"+c.getCOUNTRY()+"' already exist!");

        c.setCOUNTRY(c.getCOUNTRY().toUpperCase());
        return countryToDto(countryDao.save(dtoToCountry(c)));
    }
    @Override
    public CountryDto getCountryById(int id) {
        return countryToDto(countryDao.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Country with id '" + id + "' Not Found!")));
    }

    @Override
    public List<CountryDto> getAllCountries(int pageNumber, int pageSize, String sortBy, String sortDirection) {
        Sort sort = (sortDirection.equalsIgnoreCase("asc")) ?
                Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();

        Pageable pageable = PageRequest.of(pageNumber, pageSize, sort);
        Page<country> pageCountry = countryDao.findAll(pageable);
        return countriesToDtos(pageCountry.getContent());
    }

    @Override
    public CountryDto updateCountry(CountryDto c, int id) {
        // HANDLE IF COUNTRY EXIST BY ID
        country country = countryDao.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Country with Id '" + id + "' not found!"));

        // HANDLE DUPLICATE ENTRY EXCEPTION
        country existedCountry = countryDao.findByCountryName(c.getCOUNTRY());
        if(existedCountry != null)
            throw new DuplicateEntryException("Country with name '"+c.getCOUNTRY()+"' already exist!");

        country.setCOUNTRY(c.getCOUNTRY().toUpperCase());
        country.setSTATUS(c.isSTATUS());
        country.setDELETED(c.isDELETED());
        return countryToDto(countryDao.save(country));

    }

    @Override
    public String deleteCountryById(int id) {
        countryDao.findById(id).orElseThrow(() -> new ResourceNotFoundException("Country with Id '" + id + "' not found!"));

        countryDao.deleteById(id);
        return "Country with Id '" + id + "' deleted";
    }

    @Override
    public String softDeleteCountryById(int id) {

        country country = countryDao.findById(id).orElseThrow(() -> new ResourceNotFoundException("Country with Id '" + id + "' not found!"));
        country.setDELETED(true);
        countryDao.save(country);
        return "Country with Id '" + id + "' Soft Deleted";
    }

    @Override
    public String restoreCountryById(int id) {
        country country = countryDao.findById(id).orElseThrow(() -> new ResourceNotFoundException("Country with Id '" + id + "' not found!"));
        country.setDELETED(false);
        countryDao.save(country);
        return "Country with id '" + id + "' restored!";
    }


}
