package com.vaistra.entity;


import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

@Data
@Entity
@SQLDelete(sql = "UPDATE COUNTRY SET STATUS = true WHERE NO=?")
@Where(clause = "STATUS=false")
public class country {


    public country(int NO, String COUNTRY,boolean DELETED, boolean STATUS) {
        this.NO = NO;
        this.COUNTRY = COUNTRY;
        this.DELETED = DELETED;
        this.STATUS = STATUS;


    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int NO;
    @NotEmpty(message = "not empty Enter valid name")
    private String COUNTRY;
    private boolean STATUS=true;
    private boolean DELETED = false;



    public int getNO() {
        return NO;
    }

    public void setNO(int NO) {

        this.NO = NO;
    }
    public String getCOUNTRY() {
        return COUNTRY;
    }

    public void setCOUNTRY(String COUNTRY) {
        this.COUNTRY = COUNTRY;
    }

    public boolean isSTATUS() {
        return STATUS;
    }

    public void setSTATUS(boolean STATUS) {
        this.STATUS = STATUS;
    }

    public boolean isDELETED() {
        return DELETED;
    }

    public void setDELETED(boolean DELETED) {
        this.DELETED = DELETED;
    }

    @Override
    public String toString() {
        return "country{" +
                "NO=" + NO +
                ", COUNTRY='" + COUNTRY + '\'' +
                ", STATUS=" + STATUS +
                ", DELETED=" + DELETED +
                '}';
    }

}
