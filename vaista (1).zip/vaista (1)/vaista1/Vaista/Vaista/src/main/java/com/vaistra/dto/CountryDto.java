package com.vaistra.dto;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.Data;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

public class CountryDto {




    private int NO;




    @NotEmpty(message = "Country Should not be Empty!")
        @NotBlank(message = "Country Should not be Blank!")
        @Size(min = 3, message = "Country name should be at least 3 characters!")

        private String COUNTRY;
        private boolean STATUS=true;
        private boolean DELETED = false;

    public CountryDto() {
    }

    public CountryDto(int no, String COUNTRY, boolean STATUS, boolean DELETED) {
        this.NO = NO;
        this.STATUS = STATUS;
        this.COUNTRY = COUNTRY;
        this.DELETED=DELETED;


    }


    public int getNO() {
            return NO;
        }

        public void setNO(int NO) {

            this.NO = NO;
        }
        public String getCOUNTRY() {
            return COUNTRY;
        }

        public void setCOUNTRY(String COUNTRY) {
            this.COUNTRY = COUNTRY;
        }

        public boolean isSTATUS() {
            return STATUS;
        }

        public void setSTATUS(boolean STATUS) {
            this.STATUS = STATUS;
        }

        public boolean isDELETED() {
            return DELETED;
        }

        public void setDELETED(boolean DELETED) {
            this.DELETED = DELETED;
        }

        @Override
        public String toString() {
            return "country{" +
                    "NO=" + NO +
                    ", COUNTRY='" + COUNTRY + '\'' +
                    ", STATUS=" + STATUS +
                    ", DELETED=" + DELETED +
                    '}';
        }



}
